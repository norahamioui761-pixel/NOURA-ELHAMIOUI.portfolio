# Atelier stagiaires

Inscription de stagiaires (nom, prénom, ville, photo) + liste.
HTML/JS, PHP (mysqli), MySQL (Aiven), Cloudinary, Vercel.

## Étapes
1. Aiven : exécuter `schema.sql` dans la base.
2. Copier le certificat de la base dans `certs/ca.pem`.
3. Créer un repository GitHub et y pousser ce dossier.
4. Importer le repository dans Vercel.
5. Vercel > Settings > Environment Variables :
   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD, CLOUDINARY_URL
6. Déployer. Tester `/api/liste.php` puis `/` et `/liste.html`.

Ne jamais écrire de mot de passe dans le code ni le pousser sur GitHub.
