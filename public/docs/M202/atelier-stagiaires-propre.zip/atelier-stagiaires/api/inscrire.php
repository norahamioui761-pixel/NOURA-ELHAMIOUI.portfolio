<?php
// Inscription d'un stagiaire : upload Cloudinary + INSERT MySQL (mysqli)
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/config/db.php';

use Cloudinary\Configuration\Configuration;
use Cloudinary\Api\Upload\UploadApi;

function repondre(int $code, array $data): void
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    repondre(405, ['success' => false, 'message' => 'Méthode non autorisée.']);
}

try {
    $nom    = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $ville  = trim($_POST['ville'] ?? '');

    if ($nom === '' || $prenom === '' || $ville === '') {
        repondre(422, ['success' => false, 'message' => 'Tous les champs sont obligatoires.']);
    }

    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        repondre(422, ['success' => false, 'message' => 'Veuillez sélectionner une photo valide.']);
    }

    if ($_FILES['photo']['size'] > 5 * 1024 * 1024) {
        repondre(422, ['success' => false, 'message' => 'La photo ne doit pas dépasser 5 Mo.']);
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['photo']['tmp_name']);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        repondre(422, ['success' => false, 'message' => 'Format de photo non accepté (JPG, PNG ou WebP).']);
    }

    // 1. Envoi de la photo vers Cloudinary
    Configuration::instance(getenv('CLOUDINARY_URL'));
    $upload = (new UploadApi())->upload($_FILES['photo']['tmp_name'], ['folder' => 'stagiaires']);
    $photo_url = $upload['secure_url'];

    // 2. Enregistrement dans MySQL
    $conn = getDatabase();
    $stmt = $conn->prepare('INSERT INTO stagiaires (nom, prenom, ville, photo_url) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('ssss', $nom, $prenom, $ville, $photo_url);
    $stmt->execute();

    repondre(201, ['success' => true, 'message' => 'Stagiaire inscrit avec succès !']);
} catch (Throwable $e) {
    error_log((string) $e);
    repondre(500, ['success' => false, 'message' => 'Erreur serveur. Vérifiez la configuration (base de données, Cloudinary).']);
}
