<?php
// Retourne la liste des stagiaires en JSON : { success: true, data: [...] }
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/config/db.php';

try {
    $conn = getDatabase();

    // SELECT * : fonctionne que la colonne s'appelle "photo" ou "photo_url"
    $result = $conn->query("SELECT * FROM stagiaires ORDER BY id DESC");
    if (!$result) {
        throw new Exception($conn->error);
    }

    $stagiaires = [];
    while ($row = $result->fetch_assoc()) {
        $row['photo_url'] = $row['photo_url'] ?? ($row['photo'] ?? '');
        $stagiaires[] = $row;
    }

    echo json_encode(['success' => true, 'data' => $stagiaires], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log((string) $e);
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Impossible de récupérer les stagiaires.']);
}
