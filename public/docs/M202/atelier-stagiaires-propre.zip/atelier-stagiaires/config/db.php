<?php
// Connexion MySQL (Aiven) : les identifiants viennent UNIQUEMENT des variables d'environnement Vercel.
function getDatabase()
{
    $host = getenv('DB_HOST');
    $port = (int) getenv('DB_PORT');
    $name = getenv('DB_NAME');
    $user = getenv('DB_USER');
    $pass = getenv('DB_PASSWORD');

    $conn = mysqli_init();
    // Aiven impose une connexion SSL : on utilise le certificat certs/ca.pem
    $conn->ssl_set(null, null, dirname(__DIR__) . '/certs/ca.pem', null, null);

    if (!@$conn->real_connect($host, $user, $pass, $name, $port, null, MYSQLI_CLIENT_SSL)) {
        throw new Exception('Connexion à la base impossible : ' . $conn->connect_error);
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}
