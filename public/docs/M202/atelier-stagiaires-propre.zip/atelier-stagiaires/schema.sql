-- Table des stagiaires (à exécuter une seule fois dans la base Aiven)
DROP TABLE IF EXISTS stagiaires;

CREATE TABLE stagiaires (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  ville VARCHAR(100) NOT NULL,
  photo_url VARCHAR(500) NOT NULL,
  date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
